﻿namespace ExerciceTimer
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }


        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panExercice4 = new System.Windows.Forms.Panel();
            this.btnArrêterHorloge1 = new System.Windows.Forms.Button();
            this.btnDémarrerHorloge1 = new System.Windows.Forms.Button();
            this.vsbLumière = new VisualArrays.VisualCells.VisualBool();
            this.vsiNombreHorloge2 = new VisualArrays.VisualCells.VisualInt();
            this.btnArrêterHorloge2 = new System.Windows.Forms.Button();
            this.btnDémarrerHorloge2 = new System.Windows.Forms.Button();
            this.tmrHorloge1 = new System.Windows.Forms.Timer(this.components);
            this.tmrHorloge2 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.vsiNombreHorloge3 = new VisualArrays.VisualCells.VisualInt();
            this.btnDémarrerHorloge3 = new System.Windows.Forms.Button();
            this.tmrHorloge3 = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblExercice4 = new System.Windows.Forms.Label();
            this.panExercice4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panExercice4
            // 
            this.panExercice4.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panExercice4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panExercice4.Controls.Add(this.btnArrêterHorloge1);
            this.panExercice4.Controls.Add(this.btnDémarrerHorloge1);
            this.panExercice4.Controls.Add(this.vsbLumière);
            this.panExercice4.Location = new System.Drawing.Point(12, 56);
            this.panExercice4.Name = "panExercice4";
            this.panExercice4.Size = new System.Drawing.Size(181, 273);
            this.panExercice4.TabIndex = 2;
            // 
            // btnArrêterHorloge1
            // 
            this.btnArrêterHorloge1.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrêterHorloge1.Location = new System.Drawing.Point(21, 62);
            this.btnArrêterHorloge1.Name = "btnArrêterHorloge1";
            this.btnArrêterHorloge1.Size = new System.Drawing.Size(141, 27);
            this.btnArrêterHorloge1.TabIndex = 13;
            this.btnArrêterHorloge1.Text = "Arrêter horloge 1";
            this.btnArrêterHorloge1.UseVisualStyleBackColor = true;
            this.btnArrêterHorloge1.Click += new System.EventHandler(this.btnArrêterHorloge1_Click);
            // 
            // btnDémarrerHorloge1
            // 
            this.btnDémarrerHorloge1.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDémarrerHorloge1.Location = new System.Drawing.Point(21, 29);
            this.btnDémarrerHorloge1.Name = "btnDémarrerHorloge1";
            this.btnDémarrerHorloge1.Size = new System.Drawing.Size(141, 27);
            this.btnDémarrerHorloge1.TabIndex = 12;
            this.btnDémarrerHorloge1.Text = "Démarrer horloge 1";
            this.btnDémarrerHorloge1.UseVisualStyleBackColor = true;
            this.btnDémarrerHorloge1.Click += new System.EventHandler(this.btnDémarrerHorloge1_Click);
            // 
            // vsbLumière
            // 
            this.vsbLumière.FocusColor = System.Drawing.Color.Gray;
            this.vsbLumière.Location = new System.Drawing.Point(36, 106);
            this.vsbLumière.Name = "vsbLumière";
            this.vsbLumière.ReadOnly = true;
            this.vsbLumière.Size = new System.Drawing.Size(105, 146);
            this.vsbLumière.TabIndex = 10;
            this.vsbLumière.Toggle = false;
            this.vsbLumière.ValueAppearance.False.Image = global::ExercicesTimer.Properties.Resources.LightOff;
            this.vsbLumière.ValueAppearance.False.Style = VisualArrays.enuBkgStyle.Image;
            this.vsbLumière.ValueAppearance.True.Image = global::ExercicesTimer.Properties.Resources.LightOn;
            this.vsbLumière.ValueAppearance.True.Style = VisualArrays.enuBkgStyle.Image;
            // 
            // vsiNombreHorloge2
            // 
            this.vsiNombreHorloge2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.vsiNombreHorloge2.FocusColor = System.Drawing.Color.Gray;
            this.vsiNombreHorloge2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsiNombreHorloge2.Location = new System.Drawing.Point(24, 69);
            this.vsiNombreHorloge2.Maximum = 1000;
            this.vsiNombreHorloge2.Minimum = 0;
            this.vsiNombreHorloge2.Name = "vsiNombreHorloge2";
            this.vsiNombreHorloge2.ReadOnly = true;
            this.vsiNombreHorloge2.Size = new System.Drawing.Size(339, 30);
            this.vsiNombreHorloge2.TabIndex = 16;
            this.vsiNombreHorloge2.View = VisualArrays.enuIntView.GraphNumber;
            // 
            // btnArrêterHorloge2
            // 
            this.btnArrêterHorloge2.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrêterHorloge2.Location = new System.Drawing.Point(199, 33);
            this.btnArrêterHorloge2.Name = "btnArrêterHorloge2";
            this.btnArrêterHorloge2.Size = new System.Drawing.Size(164, 27);
            this.btnArrêterHorloge2.TabIndex = 15;
            this.btnArrêterHorloge2.Text = "Arrêter horloge 2";
            this.btnArrêterHorloge2.UseVisualStyleBackColor = true;
            this.btnArrêterHorloge2.Click += new System.EventHandler(this.btnArrêterHorloge2_Click);
            // 
            // btnDémarrerHorloge2
            // 
            this.btnDémarrerHorloge2.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDémarrerHorloge2.Location = new System.Drawing.Point(24, 33);
            this.btnDémarrerHorloge2.Name = "btnDémarrerHorloge2";
            this.btnDémarrerHorloge2.Size = new System.Drawing.Size(164, 27);
            this.btnDémarrerHorloge2.TabIndex = 14;
            this.btnDémarrerHorloge2.Text = "Démarrer horloge 2";
            this.btnDémarrerHorloge2.UseVisualStyleBackColor = true;
            this.btnDémarrerHorloge2.Click += new System.EventHandler(this.btnDémarrerHorloge2_Click);
            // 
            // tmrHorloge1
            // 
            this.tmrHorloge1.Interval = 500;
            this.tmrHorloge1.Tick += new System.EventHandler(this.tmrHorloge1_Tick);
            // 
            // tmrHorloge2
            // 
            this.tmrHorloge2.Interval = 125;
            this.tmrHorloge2.Tick += new System.EventHandler(this.tmrHorloge2_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.vsiNombreHorloge2);
            this.panel1.Controls.Add(this.btnArrêterHorloge2);
            this.panel1.Controls.Add(this.btnDémarrerHorloge2);
            this.panel1.Location = new System.Drawing.Point(214, 56);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(391, 126);
            this.panel1.TabIndex = 14;
            // 
            // vsiNombreHorloge3
            // 
            this.vsiNombreHorloge3.FocusColor = System.Drawing.Color.Gray;
            this.vsiNombreHorloge3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsiNombreHorloge3.GraphAppearance.BarColor = System.Drawing.Color.Yellow;
            this.vsiNombreHorloge3.Location = new System.Drawing.Point(24, 60);
            this.vsiNombreHorloge3.Maximum = 25;
            this.vsiNombreHorloge3.Minimum = 0;
            this.vsiNombreHorloge3.Name = "vsiNombreHorloge3";
            this.vsiNombreHorloge3.ReadOnly = true;
            this.vsiNombreHorloge3.Size = new System.Drawing.Size(339, 30);
            this.vsiNombreHorloge3.TabIndex = 19;
            this.vsiNombreHorloge3.Value = 25;
            this.vsiNombreHorloge3.View = VisualArrays.enuIntView.GraphNumber;
            // 
            // btnDémarrerHorloge3
            // 
            this.btnDémarrerHorloge3.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDémarrerHorloge3.Location = new System.Drawing.Point(24, 23);
            this.btnDémarrerHorloge3.Name = "btnDémarrerHorloge3";
            this.btnDémarrerHorloge3.Size = new System.Drawing.Size(164, 27);
            this.btnDémarrerHorloge3.TabIndex = 17;
            this.btnDémarrerHorloge3.Text = "Démarrer horloge 3";
            this.btnDémarrerHorloge3.UseVisualStyleBackColor = true;
            this.btnDémarrerHorloge3.Click += new System.EventHandler(this.BtnDémarrerHorloge3_Click);
            // 
            // tmrHorloge3
            // 
            this.tmrHorloge3.Tick += new System.EventHandler(this.TmrHorloge3_Tick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnDémarrerHorloge3);
            this.panel2.Controls.Add(this.vsiNombreHorloge3);
            this.panel2.Location = new System.Drawing.Point(214, 208);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(391, 121);
            this.panel2.TabIndex = 17;
            // 
            // lblExercice4
            // 
            this.lblExercice4.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Bold);
            this.lblExercice4.Location = new System.Drawing.Point(12, 29);
            this.lblExercice4.Name = "lblExercice4";
            this.lblExercice4.Size = new System.Drawing.Size(593, 24);
            this.lblExercice4.TabIndex = 0;
            this.lblExercice4.Text = "Trois horloges : tmrHorloge1, tmrHorloge2 et tmrHorloge3";
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 344);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panExercice4);
            this.Controls.Add(this.lblExercice4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Horloge, contrôle Timer ";
            this.panExercice4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panExercice4;
        private VisualArrays.VisualCells.VisualBool vsbLumière;
        private System.Windows.Forms.Button btnArrêterHorloge2;
        private System.Windows.Forms.Button btnDémarrerHorloge2;
        private System.Windows.Forms.Button btnArrêterHorloge1;
        private System.Windows.Forms.Button btnDémarrerHorloge1;
        private System.Windows.Forms.Timer tmrHorloge1;
        private VisualArrays.VisualCells.VisualInt vsiNombreHorloge2;
        private System.Windows.Forms.Timer tmrHorloge2;
        private System.Windows.Forms.Panel panel1;
        private VisualArrays.VisualCells.VisualInt vsiNombreHorloge3;
        private System.Windows.Forms.Button btnDémarrerHorloge3;
        private System.Windows.Forms.Timer tmrHorloge3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblExercice4;
    }
}

