﻿using System;
using System.Windows.Forms;
using VisualArrays;

namespace ExerciceTimer
{
    public partial class FrmPrincipal : Form
    {
        /// =============================================================================================
        /// <summary>
        /// Description :  Exercices avec des objets la classe Timer 
        /// </summary>
        /// =============================================================================================
        public const String APP_INFO = "(Matériel)";
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
        }

        #region Horloge #1  :  Timer / Événement Tick
        // --------------------------------------------------------------------------------------------
        private void btnDémarrerHorloge1_Click(object sender, EventArgs e)
        {
            // TODO 1A : Démarrer l'horloge 1
            tmrHorloge1.Start();
        }
        // --------------------------------------------------------------------------------------------
        private void btnArrêterHorloge1_Click(object sender, EventArgs e)
        {
            // TODO 1B : Arrêter l'horloge 1.
            tmrHorloge1.Stop();
        }
        // --------------------------------------------------------------------------------------------
        // Cette méthode est exécutée à chaque tic de tmrHorloge1
        private void tmrHorloge1_Tick(object sender, EventArgs e)
        {
            // TODO 1C : Inverser la valeur de la lumière selon.
            vsbLumière.Value = !vsbLumière.Value;
        }
        #endregion

        #region Horloge #2 : Timer / Événement Tick
        // --------------------------------------------------------------------------------------------
        private void btnDémarrerHorloge2_Click(object sender, EventArgs e)
        {
            // TODO 2A : Démarrer l'horloge 2.
            tmrHorloge2.Start();
        }
        // --------------------------------------------------------------------------------------------
        private void btnArrêterHorloge2_Click(object sender, EventArgs e)
        {
            // TODO 2B : Arrêter l'horloge 2.
            tmrHorloge2.Stop();
        }
        // --------------------------------------------------------------------------------------------
        // Cette méthode est exécutée à chaque tic de tmrHorloge2
        private void tmrHorloge2_Tick(object sender, EventArgs e)
        {
            // TODO 2C : Augmenter le nombre de 2.
            
            vsiNombreHorloge2.Value +=1;
        }


        #endregion

        #region Horloge #3 : Timer / Événement Tick
        private void BtnDémarrerHorloge3_Click(object sender, EventArgs e)
        {
            // TODO 3A : Vérifier si la valeur du nombre est a Minimum dans ce cas la mettre a Maximum
            // Démarrer l'horloge 3 et rendre inactif le bouton btnDémarrerHorloge3
            if (vsiNombreHorloge3.Value==vsiNombreHorloge3.Minimum)
            {
                vsiNombreHorloge3.Value = vsiNombreHorloge3.Maximum;
            }
            tmrHorloge3.Start();
            btnDémarrerHorloge3.Enabled = false;
        }
        private void TmrHorloge3_Tick(object sender, EventArgs e)
        {
            // TODO 3B : Diminuer la valeur de vsiNombreHorloge3 
            // Si la valeur devient 0 alors arrêter l'horloge 3 et rendre de nouveau disponible le bouton btnDémarrerHorloge3

            if (vsiNombreHorloge3.Value == vsiNombreHorloge3.Minimum)
            {
                tmrHorloge3.Stop();
                btnDémarrerHorloge3.Enabled = true;
            }
            else
            {
                vsiNombreHorloge3.Value -= 1;
            }
        }
        #endregion

    }
}