﻿using System;
using System.Windows.Forms;
using VisualArrays;


namespace VisualStringArrayModeImage
{ ///  ---------------------------------------------------------------------------------------------
  /// <summary>
  ///  Description    :   Illustrer l'utilisation d'un tableau pré-initialisé à 1D 
  ///                     et une VisualStringArray en mode image.
  ///                     Utilise le concept de concaténation de chaînes                   
  /// </summary>
  ///  --------------------------------------------------------------------------------------------
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(Matériel)";

        #region Déclaration d'un tableau 1D  et initialisation

        //      Tableau :  https://sites.google.com/site/notionscsharpcem/tableaux
        // ----------------------------------------------------------------------------------
        string[] m_tabMotsFruits = { "pomme", "radis", "raisin", "tomate",
                                      "ananas", "avocat", "banane", "cantaloup", 
                                      "cerise", "citron", "fraise", "kiwi", 
                                      "orange", "piment", "poire", "poivron"};

        #endregion

        // ----------------------------------------------------------------------------------
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;
        }

        #region Visualisation d'images dans une grille VisualStringArray

        // ----------------------------------------------------------------------------------
        private void BtnExerciceA_Click(object sender, EventArgs e)
        {
            // TODO A : Copier le premier mot du tableau m_tabMotsFruits dans la première cellule de la grille vsaGrilleMots
            vsaGrilleMots[0] = m_tabMotsFruits[0];
        }

        // ----------------------------------------------------------------------------------
        private void BtnExerciceB_Click(object sender, EventArgs e)
        {
            // TODO B : Copier le premier mot du tableau m_tabMotsFruits dans la première cellule de la grille vsaGrilleImages
            // Rappel, l'image est dans un dossier nommé : images et le type de fichier est .png
            vsaGrilleImages[0] = "images/" + m_tabMotsFruits[0] + ".png";
        }

        // ----------------------------------------------------------------------------------
        private void BtnExerciceC_Click(object sender, EventArgs e)
        {
            // TODO C : Copier les six premiers mots de m_tabMotsFruits dans la grille vsaGrilleMots
            for (int i = 0; i < vsaGrilleMots.Length; i++)
            {
                vsaGrilleMots[i] = m_tabMotsFruits[i];
            }
        }
        // ----------------------------------------------------------------------------------
        private void BtnExerciceD_Click(object sender, EventArgs e)
        {
            // TODO D : Copier les six premiers mots de m_tabMotsFruits dans la grille vsaGrilleImages
            for (int i = 0; i < vsaGrilleImages.Length; i++)
            {
                vsaGrilleImages[i] = "images/"+m_tabMotsFruits[i]+".png";
            }
        }
        // ----------------------------------------------------------------------------------
        private void BtnExerciceE_Click(object sender, EventArgs e)
        {
            // TODO E : Mélanger les cellules des deux grilles à l'aide de la méthode MixUp()
            vsaGrilleImages.MixUp();
            vsaGrilleMots.MixUp();
        }
        // ----------------------------------------------------------------------------------
        private void BtnExerciceF_Click(object sender, EventArgs e)
        {
            // TODO F : Copier toutes les celulles de la grille d'images dans la grille de mots
            for (int i = 0; i < vsaGrilleMots.Length; i++)
            {
                vsaGrilleMots[i] = vsaGrilleImages[i];
            }
        }
        // ----------------------------------------------------------------------------------
        private void BtnExerciceG_Click(object sender, EventArgs e)
        {
            // TODO G : Désactiver les cellules sélectionnées si elles ont la même valeur de SelectedIndex
            if (vsaGrilleMots.SelectedIndex == vsaGrilleImages.SelectedIndex)
            {
                vsaGrilleImages.DisableSelectedCell();
                vsaGrilleMots.DisableSelectedCell();
            }
        }
        // ----------------------------------------------------------------------------------
        private void BtnExerciceH_Click(object sender, EventArgs e)
        {
            // TODO H : Désactiver les cellules sélectionnées si elles contiennent le même fruit
            if ("images/"+vsaGrilleMots.SelectedValue+".png" == vsaGrilleImages.SelectedValue)
            {
                vsaGrilleMots.DisableSelectedCell();
                vsaGrilleImages.DisableSelectedCell();
            }
           

        }

        #endregion 

        #region Choix d'affichage  : en mode texte ou en image - NE PAS MODIFIER

        private void VsbModeImage_ValueChanged(object sender, EventArgs e)
        {
            if (vsbModeImage.Value)
            {
                vsaGrilleImages.View = enuStringView.ImageFile;
            }
            else
            {
                vsaGrilleImages.View = enuStringView.Text;
            }
        }




        #endregion Choix d'affichage  : en mode texte ou en image

        #region Événement SelectedIndexChanged
        private void VsaGrilleImages_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnExerciceG.Enabled = vsaGrilleMots.SelectedIndex != -1 && vsaGrilleImages.SelectedIndex != -1;
            btnExerciceH.Enabled = vsaGrilleMots.SelectedIndex != -1 && vsaGrilleImages.SelectedIndex != -1;
        }
        #endregion
    }
}
