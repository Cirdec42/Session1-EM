﻿namespace VisualStringArrayModeImage
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExerciceA = new System.Windows.Forms.Button();
            this.vsaGrilleImages = new VisualArrays.VisualStringArray();
            this.vsaGrilleMots = new VisualArrays.VisualStringArray();
            this.vsbModeImage = new VisualArrays.VisualCells.VisualBool();
            this.lblModeImage = new System.Windows.Forms.Label();
            this.lblGrilleMots = new System.Windows.Forms.Label();
            this.lblGrilleImages = new System.Windows.Forms.Label();
            this.btnExerciceB = new System.Windows.Forms.Button();
            this.btnExerciceC = new System.Windows.Forms.Button();
            this.btnExerciceD = new System.Windows.Forms.Button();
            this.btnExerciceE = new System.Windows.Forms.Button();
            this.btnExerciceG = new System.Windows.Forms.Button();
            this.btnExerciceH = new System.Windows.Forms.Button();
            this.btnExerciceF = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExerciceA
            // 
            this.btnExerciceA.Location = new System.Drawing.Point(13, 26);
            this.btnExerciceA.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExerciceA.Name = "btnExerciceA";
            this.btnExerciceA.Size = new System.Drawing.Size(497, 36);
            this.btnExerciceA.TabIndex = 0;
            this.btnExerciceA.Text = "A- Copier le premier mot du tableau dans la grille de mots";
            this.btnExerciceA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExerciceA.UseVisualStyleBackColor = true;
            this.btnExerciceA.Click += new System.EventHandler(this.BtnExerciceA_Click);
            // 
            // vsaGrilleImages
            // 
            this.vsaGrilleImages.AddressView = VisualArrays.enuAddressView.Mode1D;
            this.vsaGrilleImages.BackColor = System.Drawing.Color.White;
            this.vsaGrilleImages.CellMargin = 6;
            this.vsaGrilleImages.CellSize = new System.Drawing.Size(94, 94);
            this.vsaGrilleImages.DefaultValue = "";
            this.vsaGrilleImages.DisabledAppearance.StrikeAppearance.Style = VisualArrays.enuStrikeStyle.Cross;
            this.vsaGrilleImages.EnabledAppearance.BackgroundColor = System.Drawing.Color.White;
            this.vsaGrilleImages.EnabledAppearance.Font = new System.Drawing.Font("Arial", 10F);
            this.vsaGrilleImages.EnabledAppearance.TextColor = System.Drawing.Color.Black;
            this.vsaGrilleImages.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsaGrilleImages.Location = new System.Drawing.Point(758, 45);
            this.vsaGrilleImages.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.vsaGrilleImages.Name = "vsaGrilleImages";
            this.vsaGrilleImages.RowCount = 2;
            this.vsaGrilleImages.RowHeader.ForeColor = System.Drawing.Color.White;
            this.vsaGrilleImages.SelectionMode = System.Windows.Forms.SelectionMode.One;
            this.vsaGrilleImages.Size = new System.Drawing.Size(334, 227);
            this.vsaGrilleImages.TabIndex = 6;
            this.vsaGrilleImages.View = VisualArrays.enuStringView.ImageFile;
            this.vsaGrilleImages.SelectedIndexChanged += new System.EventHandler(this.VsaGrilleImages_SelectedIndexChanged);
            // 
            // vsaGrilleMots
            // 
            this.vsaGrilleMots.AddressView = VisualArrays.enuAddressView.Mode1D;
            this.vsaGrilleMots.BackColor = System.Drawing.Color.White;
            this.vsaGrilleMots.CellMargin = 6;
            this.vsaGrilleMots.CellSize = new System.Drawing.Size(172, 23);
            this.vsaGrilleMots.ColumnCount = 1;
            this.vsaGrilleMots.DefaultValue = "";
            this.vsaGrilleMots.DisabledAppearance.StrikeAppearance.Style = VisualArrays.enuStrikeStyle.Cross;
            this.vsaGrilleMots.EnabledAppearance.BackgroundColor = System.Drawing.Color.White;
            this.vsaGrilleMots.EnabledAppearance.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsaGrilleMots.EnabledAppearance.TextColor = System.Drawing.Color.Black;
            this.vsaGrilleMots.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsaGrilleMots.Location = new System.Drawing.Point(541, 43);
            this.vsaGrilleMots.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.vsaGrilleMots.Name = "vsaGrilleMots";
            this.vsaGrilleMots.RowCount = 6;
            this.vsaGrilleMots.RowHeader.ForeColor = System.Drawing.Color.White;
            this.vsaGrilleMots.SelectionMode = System.Windows.Forms.SelectionMode.One;
            this.vsaGrilleMots.Size = new System.Drawing.Size(198, 229);
            this.vsaGrilleMots.TabIndex = 8;
            this.vsaGrilleMots.SelectedIndexChanged += new System.EventHandler(this.VsaGrilleImages_SelectedIndexChanged);
            // 
            // vsbModeImage
            // 
            this.vsbModeImage.FocusColor = System.Drawing.Color.Gray;
            this.vsbModeImage.Location = new System.Drawing.Point(1024, 287);
            this.vsbModeImage.Name = "vsbModeImage";
            this.vsbModeImage.Size = new System.Drawing.Size(68, 23);
            this.vsbModeImage.TabIndex = 9;
            this.vsbModeImage.TabStop = false;
            this.vsbModeImage.Value = true;
            this.vsbModeImage.ValueAppearance.False.Image = global::VisualStringArrayModeImage.Properties.Resources.Off;
            this.vsbModeImage.ValueAppearance.False.Style = VisualArrays.enuBkgStyle.Image;
            this.vsbModeImage.ValueAppearance.True.Image = global::VisualStringArrayModeImage.Properties.Resources.On;
            this.vsbModeImage.ValueAppearance.True.Style = VisualArrays.enuBkgStyle.Image;
            this.vsbModeImage.ValueChanged += new System.EventHandler(this.VsbModeImage_ValueChanged);
            // 
            // lblModeImage
            // 
            this.lblModeImage.AutoSize = true;
            this.lblModeImage.Location = new System.Drawing.Point(871, 291);
            this.lblModeImage.Name = "lblModeImage";
            this.lblModeImage.Size = new System.Drawing.Size(147, 15);
            this.lblModeImage.TabIndex = 10;
            this.lblModeImage.Text = "Grille en mode image :";
            // 
            // lblGrilleMots
            // 
            this.lblGrilleMots.AutoSize = true;
            this.lblGrilleMots.Location = new System.Drawing.Point(538, 25);
            this.lblGrilleMots.Name = "lblGrilleMots";
            this.lblGrilleMots.Size = new System.Drawing.Size(102, 15);
            this.lblGrilleMots.TabIndex = 11;
            this.lblGrilleMots.Text = "Grille de mots :";
            // 
            // lblGrilleImages
            // 
            this.lblGrilleImages.AutoSize = true;
            this.lblGrilleImages.Location = new System.Drawing.Point(755, 27);
            this.lblGrilleImages.Name = "lblGrilleImages";
            this.lblGrilleImages.Size = new System.Drawing.Size(104, 15);
            this.lblGrilleImages.TabIndex = 12;
            this.lblGrilleImages.Text = "Grille d\'images :";
            // 
            // btnExerciceB
            // 
            this.btnExerciceB.Location = new System.Drawing.Point(13, 68);
            this.btnExerciceB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExerciceB.Name = "btnExerciceB";
            this.btnExerciceB.Size = new System.Drawing.Size(497, 36);
            this.btnExerciceB.TabIndex = 13;
            this.btnExerciceB.Text = "B- Copier le premier mot du tableau dans la grille d\'images";
            this.btnExerciceB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExerciceB.UseVisualStyleBackColor = true;
            this.btnExerciceB.Click += new System.EventHandler(this.BtnExerciceB_Click);
            // 
            // btnExerciceC
            // 
            this.btnExerciceC.Location = new System.Drawing.Point(13, 110);
            this.btnExerciceC.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExerciceC.Name = "btnExerciceC";
            this.btnExerciceC.Size = new System.Drawing.Size(497, 36);
            this.btnExerciceC.TabIndex = 14;
            this.btnExerciceC.Text = "C- Copier les six premiers mots du tableau dans la grille de mots";
            this.btnExerciceC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExerciceC.UseVisualStyleBackColor = true;
            this.btnExerciceC.Click += new System.EventHandler(this.BtnExerciceC_Click);
            // 
            // btnExerciceD
            // 
            this.btnExerciceD.Location = new System.Drawing.Point(13, 152);
            this.btnExerciceD.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExerciceD.Name = "btnExerciceD";
            this.btnExerciceD.Size = new System.Drawing.Size(497, 36);
            this.btnExerciceD.TabIndex = 15;
            this.btnExerciceD.Text = "D- Copier les six premiers mots du tableau dans la grille d\'images";
            this.btnExerciceD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExerciceD.UseVisualStyleBackColor = true;
            this.btnExerciceD.Click += new System.EventHandler(this.BtnExerciceD_Click);
            // 
            // btnExerciceE
            // 
            this.btnExerciceE.Location = new System.Drawing.Point(13, 194);
            this.btnExerciceE.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExerciceE.Name = "btnExerciceE";
            this.btnExerciceE.Size = new System.Drawing.Size(497, 36);
            this.btnExerciceE.TabIndex = 16;
            this.btnExerciceE.Text = "E- Mélanger les cellules des deux grilles avec la méthode MixUp()";
            this.btnExerciceE.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExerciceE.UseVisualStyleBackColor = true;
            this.btnExerciceE.Click += new System.EventHandler(this.BtnExerciceE_Click);
            // 
            // btnExerciceG
            // 
            this.btnExerciceG.Enabled = false;
            this.btnExerciceG.Location = new System.Drawing.Point(13, 278);
            this.btnExerciceG.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExerciceG.Name = "btnExerciceG";
            this.btnExerciceG.Size = new System.Drawing.Size(497, 36);
            this.btnExerciceG.TabIndex = 17;
            this.btnExerciceG.Text = "G- Désactiver les cellules sélectionnées, si elles ont le même SelectedIndex";
            this.btnExerciceG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExerciceG.UseVisualStyleBackColor = true;
            this.btnExerciceG.Click += new System.EventHandler(this.BtnExerciceG_Click);
            // 
            // btnExerciceH
            // 
            this.btnExerciceH.Enabled = false;
            this.btnExerciceH.Location = new System.Drawing.Point(13, 322);
            this.btnExerciceH.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExerciceH.Name = "btnExerciceH";
            this.btnExerciceH.Size = new System.Drawing.Size(497, 36);
            this.btnExerciceH.TabIndex = 18;
            this.btnExerciceH.Text = "H- Désactiver les cellules sélectionnées, si elles contiennent le même fruit";
            this.btnExerciceH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExerciceH.UseVisualStyleBackColor = true;
            this.btnExerciceH.Click += new System.EventHandler(this.BtnExerciceH_Click);
            // 
            // btnExerciceF
            // 
            this.btnExerciceF.Location = new System.Drawing.Point(13, 234);
            this.btnExerciceF.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExerciceF.Name = "btnExerciceF";
            this.btnExerciceF.Size = new System.Drawing.Size(497, 36);
            this.btnExerciceF.TabIndex = 19;
            this.btnExerciceF.Text = "F- Copier toutes les cellules de la grille d\'images dans la grille de mots";
            this.btnExerciceF.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExerciceF.UseVisualStyleBackColor = true;
            this.btnExerciceF.Click += new System.EventHandler(this.BtnExerciceF_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 376);
            this.Controls.Add(this.btnExerciceF);
            this.Controls.Add(this.btnExerciceH);
            this.Controls.Add(this.btnExerciceG);
            this.Controls.Add(this.btnExerciceE);
            this.Controls.Add(this.btnExerciceD);
            this.Controls.Add(this.btnExerciceC);
            this.Controls.Add(this.btnExerciceB);
            this.Controls.Add(this.lblGrilleImages);
            this.Controls.Add(this.lblGrilleMots);
            this.Controls.Add(this.lblModeImage);
            this.Controls.Add(this.vsbModeImage);
            this.Controls.Add(this.vsaGrilleMots);
            this.Controls.Add(this.btnExerciceA);
            this.Controls.Add(this.vsaGrilleImages);
            this.Font = new System.Drawing.Font("Lucida Sans", 9.75F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VisualStringArray en mode image ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnExerciceA;
        private VisualArrays.VisualStringArray vsaGrilleImages;
        private VisualArrays.VisualStringArray vsaGrilleMots;
        private VisualArrays.VisualCells.VisualBool vsbModeImage;
        private System.Windows.Forms.Label lblModeImage;
        private System.Windows.Forms.Label lblGrilleMots;
        private System.Windows.Forms.Label lblGrilleImages;
        private System.Windows.Forms.Button btnExerciceB;
        private System.Windows.Forms.Button btnExerciceC;
        private System.Windows.Forms.Button btnExerciceD;
        private System.Windows.Forms.Button btnExerciceE;
        private System.Windows.Forms.Button btnExerciceG;
        private System.Windows.Forms.Button btnExerciceH;
        private System.Windows.Forms.Button btnExerciceF;
    }
}

