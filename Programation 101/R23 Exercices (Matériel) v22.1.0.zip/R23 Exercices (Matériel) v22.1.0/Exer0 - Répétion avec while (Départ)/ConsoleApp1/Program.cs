﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Afficher la chaîne "Bonjour" 10 fois dans la console 
            for (int cpt = 1; cpt <= 10; cpt++)
            {
                Console.WriteLine("Bonjour");
            }
        }
    }
}
